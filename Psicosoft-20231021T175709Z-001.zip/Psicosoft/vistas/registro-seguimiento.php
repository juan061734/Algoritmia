<?php
require_once 'header.php';
?>

<div class="container">
<div class="card ">
    <div class="card-header">
        <h1>Registro de seguimiento</h1>
    </div>
    <div class="card-body">
        <form>
            <div class="row">
                <div class="col mb-3">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Observación</label>
                        <textarea class="form-control" name="" id="" cols="30" rows="10"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Seleccionar el incidente</label>
                        <select class="form-control" id="exampleFormControlSelect1" required>
                            <option>Agredir</option>
                            <option>Consumo de sustancias</option>
                            <option>Falta a las figuras de autoridad</option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Seleccionar el incidente</label>
                        <select class="form-control" id="exampleFormControlSelect1" required>
                            <option>La ayuda del cero</option>
                            <option>Privación de visitas y llamadas</option>
                            <option>Realización de planas</option>
                        </select>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="card-footer text-muted">
    <a href="listaSeguimiento1.php" class="btn btn-primary mt-4" >Regresar</a>

    <!-- este boton se debe enlazar al archivo de seguimiento Pedro  -->
    <a href="listaSeguimiento1.php" class="btn btn-success mt-4" >Guardar</a> 
    </div>
</div>
</div>











<?php
require_once 'footer.php';
?>