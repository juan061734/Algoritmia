<?php
require_once 'header.php';
?>

<div class="container w-50">
    <br>
    <h1 class="text-dark"><i class="bi bi-question-circle-fill"></i> Gestión de ayudas al aplicativo </h1> <br>
    <table class="table table-bordered ">
        <thead>
            <tr>
                <th scope="col">Módulo</th>
                <th scope="col">Video</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Dashboard</td>
                <td>
                    <a href="" class="btn btn-info"><i class="bi bi-film"></i> link </a>
                </td>
            </tr>
            <tr>
                <td>Usuarios</td>
                <td>
                    <a href="" class="btn btn-info"><i class="bi bi-film"></i> link </a>
                </td>
            </tr>
            <tr>
                <td>Configuración</td>
                <td>
                    <a href="" class="btn btn-info"><i class="bi bi-film"></i> link </a>
                </td>
            </tr>
            <tr>
                <td>Historia clinica</td>
                <td>
                    <a href="" class="btn btn-info"><i class="bi bi-film"></i> link </a>
                </td>
            </tr>
            <tr>
                <td>Seguimiento</td>
                <td>
                    <a href="" class="btn btn-info"><i class="bi bi-film"></i> link </a>
                </td>
            </tr>
        </tbody>
    </table>
</div>



<?php
require_once 'footer.php';
?>