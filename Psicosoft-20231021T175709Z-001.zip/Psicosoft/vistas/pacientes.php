<?php
    require_once 'header.php';
?>

<div class="container">
    <br>
    <h1 class="text-dark"><i class="bi bi-person-lines-fill"></i> GESTIÓN DE PACIENTES</h1><br>


    <a href="crearPaciente.php" type="button" class="btn btn-success" >
    <i class="bi bi-person-plus-fill"></i> Nuevo Paciente
    </a>
<br><br>
<table id="example" class="table table-striped" style="width:100%">
    <thead>
        <tr>
            <th>ID</th>
            <th>Documento</th>
            <th>Nombre</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tr>
        <td>001</td>
        <td>1027524657</td>
        <td>Jorge Andres Marín Castañeda</td>
        <td>
            <!--Historia Clinica-->
            <a href="listaHistoriaClinica.php" class="btn btn-primary"><i class="bi bi-bezier2"></i> Historia Cliníca</a>
            <!--Seguimiento-->
            <a href="listaSeguimiento.php" class="btn btn-success"><i class="bi bi-bar-chart-steps"></i> Seguimiento</a>
            <!--cambiar estado-->
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                <i class=" bi bi-person-dash-fill"></i>
            </button>

            <!-- Modal -->
            <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalEliminar">Inhabilitar Paciente</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ¿Seguro que desea inhabilitar a este paciente?
                        </div>
                        <div class="modal-footer">
                            <a href="" class="btn btn-success">Aceptar</a>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>
            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i
                    class="bi bi-pencil-square"></i></button>

            <!-- Modal Editar -->
            <div class="modal fade" id="editar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Gestión de Pacientes</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <h2 class="page-header">Editar Datos Personales</h2>
                                <form>
                                    <div class="form-group">
                                        <!-- nombre -->
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre</label>
                                            <input type="text" class="form-control" id="nombre" name="nombre"
                                                placeholder="Jorge Andres" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="apellidos" class="form-label">Apellidos</label>
                                            <input type="text" class="form-control" id="apellidos" name="apellidos"
                                                placeholder="Marín Castañeda" required>
                                        </div>
                                        <!-- identificacion -->
                                        <div class="mb-3">
                                            <label for="identificacion" class="form-label">Identificacion</label>
                                            <input type="text" class="form-control" id="identificacion" name="identificacion"
                                                placeholder="1030908654" required>
                                        </div>

                                        <!-- nacimiento -->
                                        <div class="mb-3">
                                            <label for="nacimiento" class="form-label">Fecha de Nacimiento</label>
                                            <input type="date" class="form-control" id="nacimiento" name="nacimiento"
                                                required>
                                        </div>
                                        <!-- direccion -->
                                        <div class="mb-3">
                                            <label for="direccion" class="form-label">Direccion</label>
                                            <input type="text" class="form-control" id="direccion" name="direccion"
                                                placeholder="Cra 30B Nº 25-56">
                                        </div>
                                        <!-- telefono -->
                                        <div class="mb-3">
                                            <label for="telefono" class="form-label">Telefono</label>
                                            <input type="text" class="form-control" id="telefono" name="telefono"
                                                placeholder="3007558798">
                                        </div>
                                        <!-- estadoCivil -->
                                        <div class="mb-3">
                                            <label for="estadoCivil" class="form-label">Estado Civil</label>
                                            <input type="text" class="form-control" id="estadoCivil" name="estadoCivil"
                                                placeholder="Soltero">
                                        </div>
                                         <!-- nivel educativo -->
                                         <div class="mb-3">
                                            <label for="nivel educativo" class="form-label">Nivel Educativo</label>
                                            <input type="text" class="form-control" id="nivel educativo" name="nivel educativo"
                                                placeholder="Bachiller">
                                        </div>
                                        <!-- acudiente -->
                                        <div class="mb-3">
                                            <label for="acudiencia" class="form-label">Acudiente</label>
                                            <input type="text" class="form-control" id="acudiencia" name="acudiencia"
                                                placeholder="Maria Antonieta Serna">
                                        </div>
                                         <!-- telefono acudiente -->
                                         <div class="mb-3">
                                            <label for="telefono" class="form-label">Telefono</label>
                                            <input type="text" class="form-control" id="telefono" name="telefono"
                                                placeholder="3104557654">
                                        </div>
                                        <!-- ingreso -->
                                        <div class="mb-3">
                                            <label for="ingreso" class="form-label">Fecha de Ingreso</label>
                                            <input type="date" class="form-control" id="ingreso" name="ingreso"
                                                required>
                                        </div>
                                       
                                        <!-- opciones -->
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-success">Guardar</button>
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Cancelar</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </td>
    </tr>
</table>
</div>


<?php
    require_once 'footer.php';
?>