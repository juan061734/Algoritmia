<?php
    require_once 'header.php';
?>

<div class="container">
    <br>
    <h1 class="text-dark"><i class="bi bi-bar-chart-steps"></i> SEGUIMIENTO</h1><br>
    <H5>Jorge Andrés Marín Castañeda</H5><br>       
    
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>ID Seguimiento</th>
                <th>Fecha de Seguimiento</th>
                <th>Operador</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tr>
        <td>001</td>
        <td>2020/01/15</td>
        <td>Andrés Parra</td>
        <td>
            <!--Ver-->
            <a class="btn btn-success" href="detalle-seguimiento.php"><i class="bi bi-eye"></i> Ver</a>
        </td>
    </table>
    <!--Regresar a Gestión de pacientes-->
    <a class="btn btn-primary" href= "pacientes.php"> Volver </a>
</div>

<?php
    require_once 'footer.php';
?>