<?php
require_once 'header.php';
?>

<div class="container">
    <br>
    <h1 class="text-dark"><i class="bi bi-exclamation-octagon-fill"></i> GESTIÓN DE INCIDENTES</h1><br>

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
    <i class="bi bi-folder-plus"></i> Registrar Incidente 
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Gestión Incidente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <h2 class="page-header">Registrar Incidente</h2>
                        <form>
                            <div class="form-group">

                                <!-- nombre Incidente-->
                                <div class="mb-3">
                                    <label for="nombre" class="form-label">Nombre del incidente</label>
                                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Ingresar Nombre" required>
                                </div>


                                <!-- Descripción-->
                                <div class="mb-3">
                                    <label for="descripcion" class="form-label">Descripción</label>
                                    <textarea name="descripcion" id="descripcion" cols="50" rows="5" placeholder="Descripción del incidente presentado..." required></textarea>

                                </div>

                                <!-- Gravedad-->
                                <div class="mb-3">
                                    <label for="gravedad" class="form-label">Seleccione la gravedad</label>
                                    <select class="form-control" name="gravedad" id="gravedad" required>
                                        <option>Alta</option>
                                        <option>Baja</option>
                                    </select>
                                </div>

                                <!-- opciones -->
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<p></p>

<table id="example" class="table table-striped" style="width:100%">
    <thead>
        <tr>

            <th>Incidente</th>
            <th>Descripión</th>
            <th>Gravedad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tr>

        <td>Agredir</td>
        <td>Pegar con ganas</td>
        <td>Alta</td>
        <td>
            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i class="bi bi-pencil-square"></i></button>
        </td>
    </tr>
    <tr>

        <td>Consumo de sustancias</td>
        <td>Consumo de sustancias dentro del hogar</td>
        <td>Alta</td>
        <td>
            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i class="bi bi-pencil-square"></i></button>
        </td>
    </tr>
    <tr>

        <td>Falta a las figuras de autoridad</td>
        <td>Agresion verbal o fisica a las directivas de la fundacion</td>
        <td>Alta</td>
        <td>
            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i class="bi bi-pencil-square"></i></button>
        </td>
    </tr>
</table>

<!-- boton regresar -->
<a href="seguimientoActitudinal.php" class="btn btn-primary mt-4" >Volver</a>


<!-- Modal Editar -->
<div class="modal fade" id="editar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Gestión de Incidente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <h2 class="page-header">Editar Incidente</h2>
                    <form>
                            <div class="form-group">

                                <!-- nombre Incidente-->
                                <div class="mb-3">
                                    <label for="nombre" class="form-label">Nombre del incidente</label>
                                    <input type="text" class="form-control" id="nombre" name="nombre" value="Agredir" required>
                                </div>


                                <!-- Descripción-->
                                <div class="mb-3">
                                    <label for="descripcion" class="form-label">Descripción</label>
                                    <textarea name="descripcion" id="descripcion" cols="50" rows="5" placeholder="Descripción del incidente presentado..." required >
                                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nam culpa autem distinctio modi magni, quibusdam ipsam deleniti. Optio voluptates soluta placeat, cum at quasi! Soluta esse ullam minus eaque voluptates.
                                    </textarea>

                                </div>

                                <!-- Gravedad-->
                                <div class="mb-3">
                                    <label for="gravedad" class="form-label">Seleccione la gravedad</label>
                                    <select class="form-control" name="gravedad" id="gravedad" required>
                                        <option>Alta</option>
                                        <option>Baja</option>
                                    </select>
                                </div>

                                <!-- opciones -->
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                </div>


                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>


<?php
require_once 'footer.php';
?>