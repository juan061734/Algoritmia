<?php
require_once 'header.php';
?>




<div class="container">
    <div class="card">
        <div class="card-body">
        <h4 class="card-tittle">Detalle del Seguimiento</h4>
            <div class="row">
                <div class="col-sm">
                    <p><strong>Fecha: </strong> 15-01-2022</p>
                </div>
                <div class="col-sm">
                    <p><strong>Paciente: </strong> Pedro Infante</p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                 <p><strong>Descripción</strong></p>
                 <p> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime, consectetur, incidunt exercitationem quas dolore id nemo alias, ut accusantium omnis eius soluta perspiciatis placeat veniam. Explicabo omnis quasi ullam maxime!
                 Sunt eum officiis voluptas rem rerum unde asperiores atque odit totam! Molestias libero maiores suscipit voluptate, adipisci minima autem, facilis voluptas et facere vero! Iste doloremque fugit quis possimus error?
                 Quis cupiditate laudantium, amet voluptatum eos consequuntur atque, accusantium fugiat nulla debitis tenetur alias quidem. Aperiam repellat dolorem deleniti voluptatum, possimus dolorum sit ex perferendis veniam itaque aliquid aliquam iste!</p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                   <p><strong>Ayuda: </strong> La ayuda del cero</p>
                </div>
                <div class="col-sm">
                    <p><strong>Incidente: </strong>Falta a las figuras de autoridad</p>
                </div>
            </div>
        </div>

    </div>
    <a href="listaSeguimiento.php" class="btn btn-primary mt-4" >Volver</a>
</div>







<?php
require_once 'footer.php';
?>