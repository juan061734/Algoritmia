<?php
    require_once 'header.php';
?>

<div class="container-sm">
    <div>
    <center><h2 class="text-dark"><i class="bi bi-person-plus-fill"></i> NUEVO PACIENTE</h2> </center> 
    </div>
    <br>
    <form class="row g-3">
        <div class="col-md-6">
            <label for="inputEmail4" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="inputEmail4" required>
        </div>
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Apellidos</label>
            <input type="text" class="form-control" id="inputPassword4" required>
        </div>
        <div class="col-md-6">
            <label for="inputEmail4" class="form-label">Identificacion</label>
            <input type="text" class="form-control" id="inputEmail4" required>
        </div>
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Fecha de Nacimiento</label>
            <input type="date" class="form-control" id="inputPassword4" required>
        </div>
        <div class="col-md-6">Direccion</label>
            <input type="email" class="form-control" id="inputEmail4" required>
        </div>
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Telefono</label>
            <input type="password" class="form-control" id="inputPassword4" required>
        </div>
        <div class="col-md-6">Estado civil</label>
            <select class="form-select form-select" aria-label=".form-select-sm example">
                <option selected>Seleccione...</option>
                <option value="1">Casado</option>
                <option value="2">Soltero</option>
                <option value="3">Union Libre</option>
            </select>
        </div>
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Nivel Educativo</label>
            <input type="password" class="form-control" id="inputPassword4" required>
        </div>
        <div class="col-md-6">Acudiente</label>
            <input type="email" class="form-control" id="inputEmail4" required>
        </div>
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Telefono</label>
            <input type="password" class="form-control" id="inputPassword4" required>
        </div>
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Fecha de Ingreso</label>
            <input type="date" class="form-control" id="inputPassword4" required>
        </div>

        <!--Formulario de texto-->
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2"><strong>Antecedentes Médicos:</strong></label>
            
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Antecedentes Psicólogicos</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Naturaleza de la remisión</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Motivo de consulta (Expectativas)    </label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Impresión Diagnóstica/ Evaluación del estado mental</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Historial de consumo</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Historial terapéutico</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Historia familiar</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Objetivos Terapeuticos</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Observaciones</label>
        </div>

        
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Psicólogo</label>
            <input type="text" class="form-control" id="inputPassword4" placeholder="Nombre del Psicologo">
        </div>
        
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Fecha de Atencion</label>
            <input type="date" class="form-control" id="inputPassword4" required>
        </div>

        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <a href="pacientes.php" type="button" class="btn btn-success">Guardar</a>
            <a href="pacientes.php" type="button" class="btn btn-secondary"
                data-bs-dismiss="modal">Cancelar</a>
        </div>
    </form>  
</div>


<?php
    require_once 'footer.php';
?>