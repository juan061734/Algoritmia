<?php
require_once 'header.php';
?>

<div class="container">
    <br>
    <h1 class="text-dark"><i class="bi bi-clipboard2-data-fill"></i> GESTIÓN DE AYUDAS</h1><br>

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Registrar Ayudas <i class="bi bi-folder-plus"></i>
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Gestión ayudas</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <h2 class="page-header">Registrar ayudas</h2>
                        <form>
                            <div class="form-group">

                                <!-- nombre ayudas-->
                                <div class="mb-3">
                                    <label for="nombre" class="form-label">Nombre de la ayuda</label>
                                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Ingresar Nombre" required>
                                </div>


                                <!-- Descripción-->
                                <div class="mb-3">
                                    <label for="descripcion" class="form-label">Descripción</label>
                                    <textarea name="descripcion" id="descripcion" cols="50" rows="5" placeholder="Descripción del incidente presentado..." required></textarea>

                                </div>


                                <!-- opciones -->
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<p></p>

<table id="example" class="table table-striped" style="width:100%">
    <thead>
        <tr>

            <th>Ayuda</th>
            <th>Descripción</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tr>

        <td>La ayuda del cero</td>
        <td>Al interno que cometio la falta, no le puede hablar a nadie, y el no le debe dirigir la palabra a nadie</td>
        <td>
            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i class="bi bi-pencil-square"></i></button>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                <i class=" bi bi-trash"></i>
            </button>
        </td>
    </tr>
    <tr>

        <td>Privación de visitas y llamadas</td>
        <td>No puede recibir llamadas ni visitas de sus familiares</td>
        <td>
            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i class="bi bi-pencil-square"></i></button>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                <i class=" bi bi-trash"></i>
            </button>
        </td>
    </tr>
    <tr>

        <td>Realización de planas</td>
        <td>De acuerdo a la falta cometida, se le asigna un numero de planas determinado</td>
        <td>
            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i class="bi bi-pencil-square"></i></button>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                <i class=" bi bi-trash"></i>
            </button>
        </td>
    </tr>
</table>

<!-- boton regresar -->
<a href="seguimientoActitudinal.php" class="btn btn-primary mt-4" >Volver</a>

<!-- Modal Eliminar-->
<div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEliminar">Eliminar Ayuda</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                ¿Seguro que desea eliminar esta ayuda?
            </div>
            <div class="modal-footer">
                <a href="" class="btn btn-success">Aceptar</a>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar -->
<div class="modal fade" id="editar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Gestión de Ayudas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <h2 class="page-header">Editar Ayuda</h2>
                    <form>
                        <div class="form-group">

                            <!-- nombre Ayudas-->
                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre de la ayuda</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" value="Agredir" required>
                            </div>


                            <!-- Descripción-->
                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción</label>
                                <textarea name="descripcion" id="descripcion" cols="50" rows="5" placeholder="Descripción del incidente presentado..." required>
                                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nam culpa autem distinctio modi magni, quibusdam ipsam deleniti. Optio voluptates soluta placeat, cum at quasi! Soluta esse ullam minus eaque voluptates.
                                    </textarea>

                            </div>


                            <!-- opciones -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            </div>



                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



</div>


<?php
require_once 'footer.php';
?>