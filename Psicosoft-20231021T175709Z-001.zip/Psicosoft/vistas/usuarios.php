<?php
    require_once 'header.php';
?>

<div class="container">
    <br>
    <h1 class="text-dark"><i class="bi bi-people-fill"></i> GESTIÓN DE USUARIOS</h1><br>

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Nuevo Usuario <i class="bi bi-person-plus-fill"></i>
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Gestión de Usuarios</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <h2 class="page-header">Nuevo Usuario</h2>
                        <form>
                            <div class="form-group">
                                <!-- rol -->
                                <div class="mb-3">
                                    <label for="Cargo" class="form-label">Rol de Usuario:</label>
                                    <select class="form-control" name="cargo" id="Cargo" required>
                                        <option>Psicólogo</option>
                                        <option>Operador</option>
                                    </select>
                                </div>
                                <!-- nombre -->
                                <div class="mb-3">
                                    <label for="nombre" class="form-label">Nombre</label>
                                    <input type="text" class="form-control" id="nombre" name="nombre"
                                        placeholder="Ingresar Nombre" required>
                                </div>
                                <!-- documento -->
                                <div class="mb-3">
                                    <label for="documento" class="form-label">Documento</label>
                                    <input type="number" class="form-control" id="documento" name="documento"
                                        placeholder="Ingresar el Documento" required>
                                </div>
                                <!-- correo -->
                                <div class="mb-3">
                                    <label for="correo" class="form-label">Correo</label>
                                    <input type="email" class="form-control" id="correo" name="correo"
                                        placeholder="Ingresar Correo" required>
                                </div>
                                <!-- contraseña -->
                                <div class="mb-3">
                                    <label for="password" class="form-label">Contraseña</label>
                                    <input type="password" class="form-control" id="password" name="password"
                                        placeholder="Ingresar Contraseña" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Confirmar Contraseña</label>
                                    <input type="password" class="form-control" id="password" name="password"
                                        placeholder="Cambiar Contraseña" required>
                                </div>
                                <!-- opciones -->
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-success">Guardar</button>
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Cancelar</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<p></p>

<table id="example" class="table table-striped" style="width:100%">
    <thead>
        <tr>
            <th>ID</th>
            <th>Documento</th>
            <th>Nombre</th>
            <th>Rol</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tr>
        <td>001</td>
        <td>1037549878</td>
        <td>Daniela Montoya Restrepo</td>
        <td>Psicólogo</td>
        <td>
            <!--cambiar estado-->
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                <i class=" bi bi-person-dash-fill"></i>
            </button>

            <!-- Modal -->
            <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalEliminar">Inhabilitar Usuario</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ¿Seguro que desea inhabilitar a este usuario?
                        </div>
                        <div class="modal-footer">
                            <a href="" class="btn btn-success">Aceptar</a>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>

            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i
                    class="bi bi-pencil-square"></i></button>

            <!-- Modal Editar -->
            <div class="modal fade" id="editar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Gestión de Pacientes</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <h2 class="page-header">Editar Usuario</h2>
                                <form>
                                    <div class="form-group">
                                        <!-- rol -->
                                        <div class="mb-3">
                                            <label for="Cargo" class="form-label">Rol de Usuario:</label>
                                            <select class="form-control" name="cargo" id="Cargo" required>
                                                <option>Psicólogo</option>
                                                <option>Operador</option>
                                            </select>
                                        </div>
                                        <!-- nombre -->
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre</label>
                                            <input type="text" class="form-control" id="nombre" name="nombre"
                                                placeholder="Editar Nombre" required>
                                        </div>
                                        <!-- documento -->
                                        <div class="mb-3">
                                            <label for="documento" class="form-label">Documento</label>
                                            <input type="number" class="form-control" id="documento" name="documento"
                                                placeholder="Editar Documento" required>
                                        </div>
                                        <!-- correo -->
                                        <div class="mb-3">
                                            <label for="correo" class="form-label">Correo</label>
                                            <input type="email" class="form-control" id="correo" name="correo"
                                                placeholder="Editar Correo" required>
                                        </div>
                                        <!-- contraseña -->
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Contraseña</label>
                                            <input type="password" class="form-control" id="password" name="password"
                                                placeholder="Cambiar Contraseña" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Confirmar Contraseña</label>
                                            <input type="password" class="form-control" id="password" name="password"
                                                placeholder="Confirmar Contraseña" required>
                                        </div>
                                        <!-- opciones -->
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-success">Guardar</button>
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Cancelar</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td>002</td>
        <td>847568987</td>
        <td>Andres Felipe Machado</td>
        <td>Operador</td>
        <td>
            <!--cambiar estado-->
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                <i class=" bi bi-person-dash-fill"></i>
            </button>

            <!-- Modal -->
            <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalEliminar">Eliminar Empleado</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ¿Seguro que desea inhabilitar a este usuario?
                        </div>
                        <div class="modal-footer">
                            <a href="" class="btn btn-success">Aceptar</a>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>

            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i
                    class="bi bi-pencil-square"></i></button>

            <!-- Modal Editar -->
            <div class="modal fade" id="editar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Gestión de Pacientes</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <h2 class="page-header">Editar Usuario</h2>
                                <form>
                                    <div class="form-group">
                                        <!-- rol -->
                                        <div class="mb-3">
                                            <label for="Cargo" class="form-label">Rol de Usuario:</label>
                                            <select class="form-control" name="cargo" id="Cargo" required>
                                                <option>Psicólogo</option>
                                                <option>Operador</option>
                                            </select>
                                        </div>
                                        <!-- nombre -->
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre</label>
                                            <input type="text" class="form-control" id="nombre" name="nombre"
                                                placeholder="Editar Nombre" required>
                                        </div>
                                        <!-- documento -->
                                        <div class="mb-3">
                                            <label for="documento" class="form-label">Documento</label>
                                            <input type="number" class="form-control" id="documento" name="documento"
                                                placeholder="Editar Documento" required>
                                        </div>
                                        <!-- correo -->
                                        <div class="mb-3">
                                            <label for="correo" class="form-label">Correo</label>
                                            <input type="email" class="form-control" id="correo" name="correo"
                                                placeholder="Editar Correo" required>
                                        </div>
                                        <!-- contraseña -->
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Contraseña</label>
                                            <input type="password" class="form-control" id="password" name="password"
                                                placeholder="Cambiar Contraseña" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Confirmar Contraseña</label>
                                            <input type="password" class="form-control" id="password" name="password"
                                                placeholder="Confirmar Contraseña" required>
                                        </div>
                                        <!-- opciones -->
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-success">Guardar</button>
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Cancelar</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td>003</td>
        <td>1032455789</td>
        <td>Sara Maria Corrales</td>
        <td>Operador</td>
        <td>
            <!--cambiar estado-->
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                <i class=" bi bi-person-dash-fill"></i>
            </button>

            <!-- Modal -->
            <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalEliminar">Eliminar Empleado</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ¿Seguro que desea inhabilitar a este usuario?
                        </div>
                        <div class="modal-footer">
                            <a href="" class="btn btn-success">Aceptar</a>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>

            <!--Editar-->
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><i
                    class="bi bi-pencil-square"></i></button>

            <!-- Modal Editar -->
            <div class="modal fade" id="editar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Gestión de Pacientes</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <h2 class="page-header">Editar Usuario</h2>
                                <form>
                                    <div class="form-group">
                                        <!-- rol -->
                                        <div class="mb-3">
                                            <label for="Cargo" class="form-label">Rol de Usuario:</label>
                                            <select class="form-control" name="cargo" id="Cargo" required>
                                                <option>Psicólogo</option>
                                                <option>Operador</option>
                                            </select>
                                        </div>
                                        <!-- nombre -->
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre</label>
                                            <input type="text" class="form-control" id="nombre" name="nombre"
                                                placeholder="Editar Nombre" required>
                                        </div>
                                        <!-- documento -->
                                        <div class="mb-3">
                                            <label for="documento" class="form-label">Documento</label>
                                            <input type="number" class="form-control" id="documento" name="documento"
                                                placeholder="Editar Documento" required>
                                        </div>
                                        <!-- correo -->
                                        <div class="mb-3">
                                            <label for="correo" class="form-label">Correo</label>
                                            <input type="email" class="form-control" id="correo" name="correo"
                                                placeholder="Editar Correo" required>
                                        </div>
                                        <!-- contraseña -->
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Contraseña</label>
                                            <input type="password" class="form-control" id="password" name="password"
                                                placeholder="Cambiar Contraseña" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Confirmar Contraseña</label>
                                            <input type="password" class="form-control" id="password" name="password"
                                                placeholder="Confirmar Contraseña" required>
                                        </div>
                                        <!-- opciones -->
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-success">Guardar</button>
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Cancelar</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </td>
    </tr>
</table>
</div>


<?php
    require_once 'footer.php';
?>