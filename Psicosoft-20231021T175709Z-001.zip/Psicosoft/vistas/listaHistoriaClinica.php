<?php
    require_once 'header.php';
?>

<div class="container">
    <br>
    <h1 class="text-dark"><i class="bi bi-bezier2"></i> HISTORIA CLÍNICA</h1><br>
    <H5>Jorge Andrés Marín Castañeda</H5><br>   

    <!--Nuevo Registro-->
    <a class="btn btn-success" href="registroSesion.php"><i class="bi bi-bezier2"></i> Nuevo Registro</a>
    <p></p>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>ID HC</th>
                <th>Fecha de Atención</th>
                <th>Psicólogo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tr>
        <td>001</td>
        <td>2020/01/22</td>
        <td>Andrés Parra</td>
        <td>
            <!--Ver-->
            <a class="btn btn-success" href="detalleSesion.php"><i class="bi bi-eye"></i> Ver</a>
        </td>
    </table>
    <!--Regresar a Gestión de pacientes-->
    <a class="btn btn-primary" href= "pacientes.php"> Volver</a>
</div>


<?php
    require_once 'footer.php';
?>