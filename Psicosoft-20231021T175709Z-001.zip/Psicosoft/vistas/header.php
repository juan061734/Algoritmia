<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PSICOSOFT</title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Icon Boostrat -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="~/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.2.2/css/fixedHeader.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <!-- Modal -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</head>

<body>
    <div class="container-fluid">
        <div class="row flex-nowrap">
            <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
                <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                    <br><br>
                    <div class="dropdown pb-4">
                        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
                            id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="img/Logo.jpg" alt="hugenerd" width="50" height="50"
                                class="rounded-circle">
                            <span class="d-none d-sm-inline mx-1">@admin</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                            <li><a class="dropdown-item" href="#">usuario@psicosoft.com</a></li>
                            <li><button class="dropdown-item" data-bs-toggle="modal"
                                    data-bs-target="#editarperfil">Editar
                                    Perfil</button></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="login.php">Cerrar Sesión</a></li>
                        </ul>
                    </div>
                    <a href="dashboard.php"
                        class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                        <span class="fs-5 d-none d-sm-inline"><br><b>PSICOSOFT</b></span>
                    </a>
                    <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start"
                        id="menu">
                        <li>
                            <a href="dashboard.php" class="nav-link align-middle px-0">
                                <i class="bi bi-bar-chart-fill"></i> <span
                                    class="ms-1 d-none d-sm-inline text-white">Dashboard</span> </a>
                        </li>
                        <li>
                            <a href="#submenu2" data-bs-toggle="collapse" class="nav-link px-0 align-middle ">
                                <i class="bi bi-people-fill"></i> <span
                                    class="ms-1 d-none d-sm-inline text-white">Gestión
                                </span><i class="bi bi-caret-down-fill"></i></a>
                            <ul class="collapse nav flex-column ms-1" id="submenu2" data-bs-parent="#menu">
                                <li class="w-100">
                                    <a href="usuarios.php" class="nav-link px-0"> <span
                                            class="d-none d-sm-inline text-white"><i class="bi bi-caret-right"></i> <i
                                                class="bi bi-person-video2"></i> Usuarios</span></a>
                                </li>
                                <li>
                                    <a href="roles.php" class="nav-link px-0"> <span
                                            class="d-none d-sm-inline text-white"><i class="bi bi-caret-right"></i> <i
                                                class="bi bi-bezier"></i> Roles</span></a>
                                </li>
                                <li>
                                    <a href="pacientes.php" class="nav-link px-0"> <span
                                            class="d-none d-sm-inline text-white"><i class="bi bi-caret-right"></i> <i
                                                class="bi bi-person-lines-fill"></i> Pacientes</span></a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="seguimientoActitudinal.php" class="nav-link px-0 align-middle">
                                <i class="bi bi-box"></i> <span
                                    class="ms-1 d-none d-sm-inline text-white">Seguimiento</span>
                            </a>
                        </li>
                        <li>
                            <a href="ayuda.php" class="nav-link px-0 align-middle">
                                <i class="bi bi-question-circle-fill"></i> <span
                                    class="ms-1 d-none d-sm-inline text-white">Ayuda</span> </a>
                        </li>
                    </ul>
                    <hr>
                </div>
            </div>
            <div class="col py-3">

                <!-- Modal Editar -->
                <div class="modal fade" id="editarperfil" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Gestión de Pacientes</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="container">
                                    <h2 class="page-header">Editar Usuario</h2>
                                    <form>
                                        <div class="form-group">
                                            <!-- rol -->
                                            <div class="mb-3">
                                                <label for="Cargo" class="form-label">Rol de Usuario:</label>
                                                <select class="form-control" name="cargo" id="Cargo" required>
                                                    <option>Psicólogo</option>
                                                    <option>Operador</option>
                                                </select>
                                            </div>
                                            <!-- nombre -->
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Nombre</label>
                                                <input type="text" class="form-control" id="nombre" name="nombre"
                                                    placeholder="Nombre" required>
                                            </div>
                                            <!-- documento -->
                                            <div class="mb-3">
                                                <label for="documento" class="form-label">Documento</label>
                                                <input type="number" class="form-control" id="documento"
                                                    name="documento" placeholder="1037854987" required>
                                            </div>
                                            <!-- correo -->
                                            <div class="mb-3">
                                                <label for="correo" class="form-label">Correo</label>
                                                <input type="email" class="form-control" id="correo" name="correo"
                                                    placeholder="usuario@psicosoft.com" required>
                                            </div>
                                            <!-- contraseña -->
                                            <div class="mb-3">
                                                <label for="password" class="form-label">Contraseña</label>
                                                <input type="password" class="form-control" id="password"
                                                    name="password" placeholder="Cambiar Contraseña" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="password" class="form-label">Confirmar Contraseña</label>
                                                <input type="password" class="form-control" id="password"
                                                    name="password" placeholder="Confirmar Contraseña" required>
                                            </div>
                                            <!-- opciones -->
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Agregar</button>
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Cancelar</button>
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>