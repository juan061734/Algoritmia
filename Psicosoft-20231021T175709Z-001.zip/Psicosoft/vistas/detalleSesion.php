<?php
    require_once 'header.php';
?>

<div class="container-sm">
    <div>
    <center><h2 class="text-dark"><i class="bi bi-clipboard2-pulse-fill"></i> DETALLE SESIÓN</h2> </center> 
    </div>
    <br>
    <form class="row g-3">
        <!--Formulario de texto-->
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Objetivos Terapeuticos</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Proceso Psicólogico</label>
        </div>
        <div class="form-floating">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
            <label for="floatingTextarea2">Recomendaciones y compromisos</label>
        </div>
           
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Psicólogo</label>
            <input type="text" class="form-control" id="inputPassword4" placeholder="Nombre del Psicologo">
        </div>
        
        <div class="col-md-6">
            <label for="inputPassword4" class="form-label">Fecha de Atencion</label>
            <input type="date" class="form-control" id="inputPassword4" required>
        </div>

        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <a href="listaHistoriaClinica.php" type="button" class="btn btn-secondary"
                data-bs-dismiss="modal">Cerrar</a>
        </div>
    </form>  
</div>


<?php
    require_once 'footer.php';
?>